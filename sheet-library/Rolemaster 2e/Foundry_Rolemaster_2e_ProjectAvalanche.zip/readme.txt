Yea, it is a wild mixture of German and English and includes some homebrew rules, but this can be easily changed in the template without having programming skills.
My goal was to have as much of the rolls be done by the sheet as my math can do.
Just the open ended rolls my group prefer not to be done automatic.
For highlighting them we are using the "special effects" form the modul "Dice so Nice.
I is fun to have a fanfare and firework on a 100.
System Initiative can be changed with dropdown between quickness (for fighters) and memory (for spell users). Initiative formula in the Custom System Builder settings has to be set to:� �[2d10]+ini
Skill descriptions and Piks can be paced as links to journals. By using the PDF Pager module Spells and original character Sheets can be placed as PDF Links.
In the fields �Mac� with the help of the Advanced Macro Module combat special effects can be placed and activated with SHIFT + klick the roll.
Most rolls have via SHIFT + klick the possibility to place a modification to the roll.

Please send Questions and suggestions to eichohrkater@gmail.com
Thanks for trying out
